param(
    [Parameter(Position = 0)]
    [string]$GameDirectory,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$expectedExeHash = 'F4DD1131DF6C993C01EA011F9439BC725E6DC6491B5FBBA47724D7D5B64DA3F3'
$payloadDirectory = Join-Path $PSScriptRoot 'payload'

function Pause-IfNeeded {
    if (-not $Quiet) {
        [void](Read-Host 'Press Enter to close')
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) {
        $localExe = Join-Path $PSScriptRoot 'M1937.exe'
        if (Test-Path -LiteralPath $localExe -PathType Leaf) {
            $GameDirectory = $PSScriptRoot
        }
        else {
            $GameDirectory = Read-Host 'Enter the directory containing M1937.exe'
        }
    }

    $GameDirectory = [IO.Path]::GetFullPath($GameDirectory.Trim().Trim('"'))
    $gameRoot = $GameDirectory.TrimEnd('\') + '\'
    $targetExe = Join-Path $GameDirectory 'M1937.exe'

    if (-not (Test-Path -LiteralPath $targetExe -PathType Leaf)) {
        throw "M1937.exe was not found in: $GameDirectory"
    }
    if (-not (Test-Path -LiteralPath $payloadDirectory -PathType Container)) {
        throw 'The payload directory is missing. Extract the complete package and try again.'
    }

    Write-Host 'Checking M1937.exe...'
    $actualExeHash = (Get-FileHash -LiteralPath $targetExe -Algorithm SHA256).Hash
    Write-Host "SHA-256: $actualExeHash"
    if ($actualExeHash -ne $expectedExeHash) {
        throw 'Unsupported M1937.exe version. No patch files were installed.'
    }

    $payloadFiles = @(Get-ChildItem -LiteralPath $payloadDirectory -Recurse -File)
    if ($payloadFiles.Count -eq 0) {
        throw 'The payload directory is empty.'
    }

    $backupDirectory = Join-Path $GameDirectory '.1937-compat-backup-before-v1.1.0'
    $backupMarker = Join-Path $backupDirectory 'backup-complete.txt'

    if (-not (Test-Path -LiteralPath $backupMarker -PathType Leaf)) {
        Write-Host 'Backing up existing compatibility files...'
        New-Item -ItemType Directory -Force -Path $backupDirectory | Out-Null

        foreach ($source in $payloadFiles) {
            $relative = $source.FullName.Substring($payloadDirectory.Length + 1)
            $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
            if (-not $destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase)) {
                throw "Unsafe payload path: $relative"
            }
            if (Test-Path -LiteralPath $destination -PathType Leaf) {
                $backupTarget = Join-Path $backupDirectory $relative
                New-Item -ItemType Directory -Force -Path (Split-Path $backupTarget) | Out-Null
                Copy-Item -LiteralPath $destination -Destination $backupTarget -Force
            }
        }

        @(
            '1937 compatibility patch v1.1.0 backup'
            'Created before the first installation. Keep this directory for recovery.'
        ) | Set-Content -LiteralPath $backupMarker -Encoding ASCII
    }

    Write-Host 'Installing compatibility patch...'
    foreach ($source in $payloadFiles) {
        $relative = $source.FullName.Substring($payloadDirectory.Length + 1)
        $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
        if (-not $destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Unsafe payload path: $relative"
        }
        New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
        Copy-Item -LiteralPath $source.FullName -Destination $destination -Force
    }

    Write-Host ''
    Write-Host 'Installation completed successfully.' -ForegroundColor Green
    Write-Host "Game directory: $GameDirectory"
    Write-Host 'Use the windowed-mode launcher in the game directory. Press Alt+Enter for fullscreen.'
    Pause-IfNeeded
    exit 0
}
catch {
    Write-Host ''
    Write-Host ('Installation failed: ' + $_.Exception.Message) -ForegroundColor Red
    Pause-IfNeeded
    exit 1
}
