param(
    [Parameter(Position = 0)]
    [string]$GameDirectory,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$payloadDirectory = Join-Path $PSScriptRoot 'payload'

function Pause-IfNeeded {
    if (-not $Quiet) {
        [void](Read-Host 'Press Enter to close')
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) {
        $localExe = Join-Path $PSScriptRoot 'M1937.exe'
        if (Test-Path -LiteralPath $localExe -PathType Leaf) {
            $GameDirectory = $PSScriptRoot
        }
        else {
            $GameDirectory = Read-Host 'Enter the directory containing M1937.exe'
        }
    }

    $GameDirectory = [IO.Path]::GetFullPath($GameDirectory.Trim().Trim('"'))
    $gameRoot = $GameDirectory.TrimEnd('\') + '\'
    $targetExe = Join-Path $GameDirectory 'M1937.exe'

    if (-not (Test-Path -LiteralPath $targetExe -PathType Leaf)) {
        throw "M1937.exe was not found in: $GameDirectory"
    }
    if (-not (Test-Path -LiteralPath $payloadDirectory -PathType Container)) {
        throw 'The payload directory is missing. Extract the complete package and try again.'
    }

    $payloadFiles = @(Get-ChildItem -LiteralPath $payloadDirectory -Recurse -File)
    Write-Host 'Removing patch files...'
    foreach ($source in $payloadFiles) {
        $relative = $source.FullName.Substring($payloadDirectory.Length + 1)
        $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
        if (-not $destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Unsafe payload path: $relative"
        }
        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            Remove-Item -LiteralPath $destination -Force
        }
    }

    $payloadDirectories = @(Get-ChildItem -LiteralPath $payloadDirectory -Recurse -Directory |
        Sort-Object { $_.FullName.Length } -Descending)
    foreach ($sourceDirectory in $payloadDirectories) {
        $relative = $sourceDirectory.FullName.Substring($payloadDirectory.Length + 1)
        $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
        if ($destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase) -and
            (Test-Path -LiteralPath $destination -PathType Container) -and
            -not (Get-ChildItem -LiteralPath $destination -Force | Select-Object -First 1)) {
            Remove-Item -LiteralPath $destination -Force
        }
    }

    $backupDirectory = Join-Path $GameDirectory '.1937-compat-backup-before-v1.1.0'
    $backupMarker = Join-Path $backupDirectory 'backup-complete.txt'
    if (Test-Path -LiteralPath $backupMarker -PathType Leaf) {
        Write-Host 'Restoring files saved before the first installation...'
        $backupFiles = @(Get-ChildItem -LiteralPath $backupDirectory -Recurse -File |
            Where-Object { $_.FullName -ne $backupMarker })
        foreach ($source in $backupFiles) {
            $relative = $source.FullName.Substring($backupDirectory.Length + 1)
            $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
            if (-not $destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase)) {
                throw "Unsafe backup path: $relative"
            }
            New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
            Copy-Item -LiteralPath $source.FullName -Destination $destination -Force
        }
    }
    else {
        Write-Host 'No first-install backup was found; there were no previous files to restore.'
    }

    Write-Host ''
    Write-Host 'Uninstallation completed successfully.' -ForegroundColor Green
    Write-Host 'The recovery backup directory was retained.'
    Pause-IfNeeded
    exit 0
}
catch {
    Write-Host ''
    Write-Host ('Uninstallation failed: ' + $_.Exception.Message) -ForegroundColor Red
    Pause-IfNeeded
    exit 1
}
