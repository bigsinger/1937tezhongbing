@echo off
call "%~dp0Uninstall-Patch.cmd" %*
exit /b %errorlevel%
