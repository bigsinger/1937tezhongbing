@echo off
chcp 65001 >nul
cd /d "%~dp0"
start "" "M1937.exe"

