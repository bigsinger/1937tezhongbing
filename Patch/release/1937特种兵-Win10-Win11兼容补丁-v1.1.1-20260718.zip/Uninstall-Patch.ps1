param(
    [Parameter(Position = 0)]
    [string]$GameDirectory,
    [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$payloadDirectory = Join-Path $PSScriptRoot 'payload'
$legacyShaderHashes = [ordered]@{
    'Shaders\crt\crt-lottes-fast-no-warp-bilinear.glsl' = 'B3321C84272230EC9D143B9995687EA8940881202DC74CA352BD05EBC5E39009'
    'Shaders\interpolation\bilinear.glsl' = 'E741A3F07096C891BF3EDFC89C82E0388ACF35CBD832FED42EDD5C9C3BC85E79'
    'Shaders\interpolation\catmull-rom-bilinear.glsl' = '18E89F829F4C82D5B1E0D1FA9B41D6698CF3FBD2D45EF8ABB9F6D7A2452C9426'
    'Shaders\interpolation\fsr.glsl' = '5E4F814DE1F7CB5B1DDAE857E325FCFCC1868798A03EA782CF06106503EF2C7E'
    'Shaders\interpolation\fsr.glsl.pass1' = '714AEFB863D42E21D876DDE55B8C2C6748773426FFE6393E36A25B6D6C6E0DE8'
    'Shaders\interpolation\jinc2-dedither.glsl' = '92F847C8E5C45D9FF0BB9BB0ECCD91CB078AA533D5434335E9F927AB4FF22614'
    'Shaders\interpolation\lanczos2-sharp.glsl' = '31CE41FF6AEA6269A36D0B805F651A95646DCEB2462B5212E366D39B2D9A8A3D'
    'Shaders\nearest-neighbor.glsl' = 'E741A3F07096C891BF3EDFC89C82E0388ACF35CBD832FED42EDD5C9C3BC85E79'
    'Shaders\readme.txt' = '067E1CF145B6F1E1C8168E40BE56B097599AFBAB602FFCA3F6B83041BDDFE794'
    'Shaders\scanlines\scanline.glsl' = 'B1712048D3EB05D115EC743F267B3880D4926F8E71601096117CE184518EA020'
    'Shaders\shader-package.zip' = 'B11FB8E9E57AA4A86F9CA5610CFE264F8BF44C5C017D92631FC80AE9C881871E'
    'Shaders\sharpen\rca-sharpen.glsl' = '714AEFB863D42E21D876DDE55B8C2C6748773426FFE6393E36A25B6D6C6E0DE8'
    'Shaders\xbr\xbr-lv2-noblend.glsl' = 'EE799699FA96CF8E517CF563BE58EF726F805095C3D5460D59B3F696A8DC09A9'
    'Shaders\xbrz\xbrz-freescale-multipass.glsl' = 'BB33262DAA8CBA06026FE09BAB2A29D60B4E89B4B966D6241AAABC9F8C5E640A'
    'Shaders\xbrz\xbrz-freescale-multipass.glsl.pass1' = '8785F14F704A4CE4A644C5E34174ECCF75DD58F85023AA9C6EFDE88956A7F64F'
}
$legacyShaderDirectories = @(
    'Shaders\interpolation',
    'Shaders\scanlines',
    'Shaders\sharpen',
    'Shaders\xbrz',
    'Shaders\xbr',
    'Shaders\crt',
    'Shaders'
)

function Pause-IfNeeded {
    if (-not $Quiet) {
        [void](Read-Host 'Press Enter to close')
    }
}

function Remove-LegacyShaders {
    param(
        [string]$RootDirectory,
        [string]$RootPrefix,
        [string]$BackupMarkerPath
    )

    if (-not (Test-Path -LiteralPath $BackupMarkerPath -PathType Leaf)) {
        return
    }
    $backupMarkerText = Get-Content -LiteralPath $BackupMarkerPath -Raw -Encoding ASCII
    if (-not $backupMarkerText.Contains('1937 compatibility patch v1.1.0 backup')) {
        return
    }

    $removedCount = 0
    foreach ($entry in $legacyShaderHashes.GetEnumerator()) {
        $relative = [string]$entry.Key
        $target = [IO.Path]::GetFullPath((Join-Path $RootDirectory $relative))
        if (-not $target.StartsWith($RootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Unsafe legacy shader path: $relative"
        }

        if (Test-Path -LiteralPath $target -PathType Leaf) {
            $actualHash = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash
            if ($actualHash -eq [string]$entry.Value) {
                Remove-Item -LiteralPath $target -Force
                $removedCount++
            }
            else {
                Write-Warning "Modified legacy shader was retained: $relative"
            }
        }
        elseif (Test-Path -LiteralPath $target) {
            Write-Warning "Non-file legacy shader path was retained: $relative"
        }
    }

    $shaderRoot = [IO.Path]::GetFullPath((Join-Path $RootDirectory 'Shaders'))
    if (-not $shaderRoot.StartsWith($RootPrefix, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Unsafe legacy shader directory.'
    }
    if (Test-Path -LiteralPath $shaderRoot -PathType Container) {
        foreach ($remainingFile in Get-ChildItem -LiteralPath $shaderRoot -Recurse -File) {
            $relative = $remainingFile.FullName.Substring($RootPrefix.Length)
            if ($legacyShaderHashes.Keys -notcontains $relative) {
                Write-Warning "Unknown shader file was retained: $relative"
            }
        }
    }

    foreach ($relative in $legacyShaderDirectories) {
        $target = [IO.Path]::GetFullPath((Join-Path $RootDirectory $relative))
        if ($target.StartsWith($RootPrefix, [StringComparison]::OrdinalIgnoreCase) -and
            (Test-Path -LiteralPath $target -PathType Container) -and
            -not (Get-ChildItem -LiteralPath $target -Force | Select-Object -First 1)) {
            Remove-Item -LiteralPath $target -Force
        }
    }

    if ($removedCount -gt 0) {
        Write-Host "Removed $removedCount unchanged shader file(s) left by patch v1.1.0."
    }
}

try {
    if ([string]::IsNullOrWhiteSpace($GameDirectory)) {
        $localExe = Join-Path $PSScriptRoot 'M1937.exe'
        if (Test-Path -LiteralPath $localExe -PathType Leaf) {
            $GameDirectory = $PSScriptRoot
        }
        else {
            $GameDirectory = Read-Host 'Enter the directory containing M1937.exe'
        }
    }

    $GameDirectory = [IO.Path]::GetFullPath($GameDirectory.Trim().Trim('"'))
    $gameRoot = $GameDirectory.TrimEnd('\') + '\'
    $targetExe = Join-Path $GameDirectory 'M1937.exe'

    if (-not (Test-Path -LiteralPath $targetExe -PathType Leaf)) {
        throw "M1937.exe was not found in: $GameDirectory"
    }
    if (-not (Test-Path -LiteralPath $payloadDirectory -PathType Container)) {
        throw 'The payload directory is missing. Extract the complete package and try again.'
    }

    $payloadFiles = @(Get-ChildItem -LiteralPath $payloadDirectory -Recurse -File)
    Write-Host 'Removing patch files...'
    foreach ($source in $payloadFiles) {
        $relative = $source.FullName.Substring($payloadDirectory.Length + 1)
        $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
        if (-not $destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Unsafe payload path: $relative"
        }
        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            Remove-Item -LiteralPath $destination -Force
        }
    }

    $payloadDirectories = @(Get-ChildItem -LiteralPath $payloadDirectory -Recurse -Directory |
        Sort-Object { $_.FullName.Length } -Descending)
    foreach ($sourceDirectory in $payloadDirectories) {
        $relative = $sourceDirectory.FullName.Substring($payloadDirectory.Length + 1)
        $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
        if ($destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase) -and
            (Test-Path -LiteralPath $destination -PathType Container) -and
            -not (Get-ChildItem -LiteralPath $destination -Force | Select-Object -First 1)) {
            Remove-Item -LiteralPath $destination -Force
        }
    }

    $backupDirectory = Join-Path $GameDirectory '.1937-compat-backup-before-v1.1.0'
    $backupMarker = Join-Path $backupDirectory 'backup-complete.txt'

    Remove-LegacyShaders `
        -RootDirectory $GameDirectory `
        -RootPrefix $gameRoot `
        -BackupMarkerPath $backupMarker

    if (Test-Path -LiteralPath $backupMarker -PathType Leaf) {
        Write-Host 'Restoring files saved before the first installation...'
        $backupFiles = @(Get-ChildItem -LiteralPath $backupDirectory -Recurse -File |
            Where-Object { $_.FullName -ne $backupMarker })
        foreach ($source in $backupFiles) {
            $relative = $source.FullName.Substring($backupDirectory.Length + 1)
            $destination = [IO.Path]::GetFullPath((Join-Path $GameDirectory $relative))
            if (-not $destination.StartsWith($gameRoot, [StringComparison]::OrdinalIgnoreCase)) {
                throw "Unsafe backup path: $relative"
            }
            New-Item -ItemType Directory -Force -Path (Split-Path $destination) | Out-Null
            Copy-Item -LiteralPath $source.FullName -Destination $destination -Force
        }
    }
    else {
        Write-Host 'No first-install backup was found; there were no previous files to restore.'
    }

    Write-Host ''
    Write-Host 'Uninstallation completed successfully.' -ForegroundColor Green
    Write-Host 'The recovery backup directory was retained.'
    Pause-IfNeeded
    exit 0
}
catch {
    Write-Host ''
    Write-Host ('Uninstallation failed: ' + $_.Exception.Message) -ForegroundColor Red
    Pause-IfNeeded
    exit 1
}
