@echo off
call "%~dp0Install-Patch.cmd" %*
exit /b %errorlevel%
