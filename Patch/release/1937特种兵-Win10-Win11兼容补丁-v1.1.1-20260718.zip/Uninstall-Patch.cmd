@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Uninstall-Patch.ps1" %*
exit /b %errorlevel%
